// JavaScript Document

window.onload = function() {
	var button = document.querySelector(".submit button");
	
	button.onclick = function() {
		var inputs = document.querySelectorAll("input");
		var selected = document.querySelector("select");
		var xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function() {
			if (xhr.readyState == 4 && xhr.status == 200)
			{
				if (xhr.responseText == "注册成功")
				{
					alert("注册成功");
					window.location.href = "login.html";
				}
				else
				{
					alert("注册失败");
				}
			}
		};
		xhr.open("post", "register", true);
		xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		xhr.send("loginId=" + inputs[0].value + 
						 "&password=" + inputs[1].value +
						 "&name=" + inputs[2].value + 
						 "&sex=" + selected.value);
	};
};

