// JavaScript Document

var interval;
var errorCount = 0;
window.onload = function() {
	addSendListener();
	interval = window.setInterval(updateMessages, 1000*3);
	var input = document.querySelector(".text input");
	input.onkeyup = keyDownListener;
};

function keyDownListener(e) {
	if (e.keyCode == 13)
	{
		var xmlhttp = new XMLHttpRequest();
		var text = document.querySelector(".text input");
		var send = document.querySelector(".send span");
		if (send.text === "")
		{
			return ;
		}
		xmlhttp.open("post", "addMessage", true);
		xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		xmlhttp.send("message=" + text.value);
		addMessage(text.value, 1);
		text.value = "";
	}
}

window.onunload = function() {
	var xhr = new XMLHttpRequest();
	xhr.open("get", "offline", true);
	xhr.send();
}

function addSendListener() {
	var text = document.querySelector(".text input");
	var send = document.querySelector(".send span");
	send.style.cursor = "pointer";
	
	send.onmouseover = function() {
		send.style.background = "rgba(150,150,150,1.00)";
	};
	send.onmouseout = function() {
		send.style.background = "rgba(124,124,124,1.00)";
	};
	
	send.onmousedown = function() {
		send.style.background = "rgba(180,180,180,1.00)";
	};

	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadstatechange = function() {
		console.log("状态更改");
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
		{
			console.log("发送信息成功");
			console.log(xmlhttp.responseText);
			addMessage(xmlhttp.responseText, 1)
		}
	};
	send.onclick = function() {
		if (send.text === "")
		{
			return ;
		}
		xmlhttp.open("post", "addMessage", true);
		xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		xmlhttp.send("message=" + text.value);
		addMessage(text.value, 1);
		text.value = "";
	};
}

function addMessage(message, position) {
	var p = document.createElement("p");
	p.innerText = message;
	if (position == 0)
	{
		p.setAttribute("class", "other");
	}
	else
	{
		p.setAttribute("class", "myself");
	}
	
	document.querySelector(".content").appendChild(p);
}


function updateMessages() {
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status != 200)
		{
			errorCount += 1;
			if (errorCount > 5)
			{
				window.clearInterval(interval);
			}
		}
		else if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
		{
//			document.querySelector("h1").innerText = xmlhttp.responseText;
			
			var texts = xmlhttp.responseText.split("&");
			var side;
			var text;
			
			var ps = document.querySelectorAll(".content p");
			var lastp = ps[ps.length-1];
			var index;
			var i;
			
			var tempIndex;
			if (ps.length == 0)
			{
				index = texts.length;
			}
			else
			{				
				for (i = 0; i < texts.length; i++) {
					tempIndex = texts[i].indexOf(",");
					text = texts[i].substr(tempIndex+1);
					if (text == lastp.innerText)
					{
						index = i;
					}
				}
			}

			for (i = index-1; i >= 0; i--) {
				tempIndex = texts[i].indexOf(",");
				side = texts[i].substr(0, tempIndex);
				text = texts[i].substr(tempIndex+1);
				if (side == 0)
				{
						side = 1;
				}
				else
				{
					side = 0;
				}
				addMessage(text, Number.parseInt(side));
			}
		}
	};
	xmlhttp.open("get", "getMessage", true);
	xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
	xmlhttp.send();
}








