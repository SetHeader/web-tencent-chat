// JavaScript Document

window.onload = function() {
	addSearchListener();
	addButtonListener();
};

window.onunload = function() {
	var xhr = new XMLHttpRequest();
	xhr.open("get", "offline", true);
	xhr.send();
};

function addSearchListener() {
	var input = document.querySelector(".search input[type='text']");
	var search = document.querySelector(".search input[type='submit']");

	search.onclick = function() {
			
			window.location.href = "searchFriend?loginId=" + input.value;
//		window.location.href = "searchFriend";
	};
}

function addButtonMouseListener(button) {
	button.onmouseover = function() {
		button.style.background="rgba(0, 150, 200, 1)";
	};
	button.onmouseout = function() {
		button.style.background="rgba(0, 199, 255, 1)";
	};
}

function addButtonClickListener(button) {
	var address = "addFriend?num=" + button.getAttribute("num");
	button.onclick = function() {
		window.location.href = address;
	};
}

function addButtonListener() {
	var buttons = document.querySelectorAll("tr td:last-child");

	for (var i = 0; i < buttons.length; i++) {
		buttons[i].style.cursor = "pointer";
		buttons[i].setAttribute("num", i);
		addButtonMouseListener(buttons[i]);
		addButtonClickListener(buttons[i]);
	}
}

function addRow(id, name, sex, state) {
	
}