// JavaScript Document

var responseText; //返回的音乐信息列表

window.onload = function() {
	var xhr = new XMLHttpRequest();	
	
	//接收到服务器信息时调用这个函数
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4 && xhr.status == 200)	//成功时执行
		{
			responseText = xhr.responseText;	//调到响应信息
			var infs = responseText.split("&");	//得到音乐信息的数组
			var inf;
			for (var i = 0; i < infs.length; i++) {
				inf = infs[i].split(",");	//得到音乐信息的每个部分
				audioFn.newSong({	//创建新歌（应该是）
					"cover": inf[0],	//第一个部分
					"src": inf[1],	//第二个部分
					"title": inf[2]	//第三个部分
				});
			}
		}
	};
	xhr.open("get", "getMusic", true);
	xhr.send();
};

audioFn.newSong({
					'cover' : 'images/cover5.jpg',
					'src' : 'songs/f.mp3',
					'title' : 'B.A.A.B'
				},false);



var records = new Array();	//记录数组

//添加记录，record是一个字符串
function addRecord(record) {
	records.push(record);
}
//上传到服务器
function uploadRecords() {
	var xhr = new XMLHttpRequest();	
	xhr.open("get", "uploadRecords?" + recordsToString(), true);
	xhr.send();
}
//数组变成一个字符串
function recordsToString() {
	var str = "";
	for (var i = 0; i < records.length; i++)
	{
		str += records[i] + "&";
	}
	if (str.length > 0)
	{
		str = str.substr(0, str.length-1);
	}
	return str;
}


