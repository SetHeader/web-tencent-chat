// JavaScript Document

window.onload = function() {
	var register = document.querySelector(".submit input[type='button']");
	register.onclick = function() {
		window.location.href = "register.html";
	};
};