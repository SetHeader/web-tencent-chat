// JavaScript Document



window.onload = function () {
	console.log("添加事件");
	var panels = document.querySelectorAll(".panel");
	for (var i = 0; i < panels.length; i++) {
		addListener(panels[i]);
		addHref(panels[i], i);
	}
	addAddFriendListener();
};

window.onunload = function() {
	var xhr = new XMLHttpRequest();
	xhr.open("get", "offline", true);
	xhr.send();
}

function addListener(panel) {
	panel.style.cursor = "pointer";
	panel.onmouseover = function () {
		this.style.background = "#EEEEEE";
	};
	panel.onmouseout = function () {
		this.style.background = "#FCFCFC";
	};
}

function addHref(panel, i) {
		panel.onclick = function () {
			window.location.href = "chat?num=" + i;
		};
}

function addAddFriendListener() {
	var button = document.querySelector(".addfriend");
	button.style.cursor = "pointer";
	button.onmouseover = function() {
		button.style.color = "#666666";
	};
	button.onmouseout = function() {
		button.style.color = "#000000";
	};
	button.onclick = function() {
		window.location.href = "searchFriend";
	};
}