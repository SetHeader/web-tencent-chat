package filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * 请求过滤器，将请求编码设置为 UTF-8
 * @author Administrator
 *
 */
public class EncodingFilter implements Filter{

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
//		System.out.println("原使用编码：" + request.getCharacterEncoding());
//		System.out.println("ContentType: " + request.getContentType());
//		System.out.println("设置请求编码为UTF-8");
		request.setCharacterEncoding("UTF-8");
		chain.doFilter(request, response);
	}
}
