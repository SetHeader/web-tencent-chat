package listener;

import java.sql.SQLException;
import java.util.HashSet;
import java.util.Map;

import javax.enterprise.inject.spi.BeanManager;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.taglibs.standard.lang.jstl.Constants;

import jdbc.UseDBProcedure;
import model.UserInf;
/**
 * 会话监听器
 * 用于监听用户的登入和登出
 * @author Administrator
 *
 */
public class UserLoginListener implements HttpSessionListener {
	
 
	/**
	 * session创建时执行的方法，用户登录时执行
	 */
	public void sessionCreated(HttpSessionEvent event) {
		HttpSession session = event.getSession();
		session.setMaxInactiveInterval(60*30);
		System.out.println("创建session");
	}
 
	/***
	 * session销毁时执行的方法，用户主动退出/浏览器关闭Session过期 时执行
	 */
	public void sessionDestroyed(HttpSessionEvent event) {
		HttpSession session = event.getSession();
		UserInf u = (UserInf) session.getAttribute("userInf");
		if (u == null)
		{
			return ;
		}
		System.out.println("用户登出 " + u.getName());
		try {
			new UseDBProcedure().userOffline(u.getId());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
