package listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import jdbc.UseDBProcedure;
/**
 * 应用监听器
 * 当服务器关闭时，调用所有用户离线方法
 * @author Administrator
 *
 */
public class MyApplicationListener implements ServletContextListener {
	@Override
	public void contextInitialized(ServletContextEvent evt){
		System.out.println("服务器打开");
	}
 
 
	@Override
	public void contextDestroyed(ServletContextEvent evt){
		System.out.println("用户全部离线");
		try {
			new UseDBProcedure().setAllOffline();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
	}
}
