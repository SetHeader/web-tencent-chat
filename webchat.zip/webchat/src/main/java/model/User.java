package model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
/**
 * 用户类，包括用户信息和好友列表
 * @author Administrator
 *
 */
public class User {
	UserInf userInf;
	List<UserInf> friends;	//好友列表就是用户信息的列表

	public User() {
		friends = new ArrayList<>();
	}

	/**
	 * @param userInf
	 * @param friends
	 */
	public User(UserInf userInf, List<UserInf> friends) {
		super();
		this.userInf = userInf;
		this.friends = friends;
	}

	public UserInf getFriendById(int id) {
		Iterator<UserInf> it = friends.iterator();
		UserInf u = null;
		boolean isFound = false;
		while (it.hasNext() && !isFound) {
			u = it.next();
			if (u.id == id) {
				isFound = true;
			}
		}

		if (!isFound) {
			u = null;
		}
		return u;
	}

	public UserInf getFriendByIndex(int index) {
		if (index >= 0 && index < friends.size())
		{
			return friends.get(index);
		}
		else
		{
			return null;
		}
	}
	
	public void addFriend(UserInf u) {
		friends.add(u);
	}

	/**
	 * @return the userInf
	 */
	public UserInf getUserInf() {
		return userInf;
	}

	/**
	 * @param userInf the userInf to set
	 */
	public void setUserInf(UserInf userInf) {
		this.userInf = userInf;
	}

	/**
	 * @return the friends
	 */
	public List<UserInf> getFriends() {
		return friends;
	}

	/**
	 * @param friends the friends to set
	 */
	public void setFriends(List<UserInf> friends) {
		this.friends = friends;
	}
}
