package model;
/**
 * 用户信息类
 * 保存用户的基本信息
 * @author Administrator
 *
 */
public class UserInf {
	int id;
	String loginId;
	String name;
	String sex;
	int state;	//0代表离线， 1代表在线
	
	public UserInf() {
		
	}
	
	/**
	 * @param id
	 * @param loginId
	 * @param name
	 * @param sex
	 * @param state
	 */
	public UserInf(int id, String loginId, String name, String sex, int state) {
		super();
		this.id = id;
		this.loginId = loginId;
		this.name = name;
		this.sex = sex;
		this.state = state;
	}
	
	
	public UserInf(int id, String loginId, String name, String sex) {
		super();
		this.id = id;
		this.loginId = loginId;
		this.name = name;
		this.sex = sex;
	}
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the loginId
	 */
	public String getLoginId() {
		return loginId;
	}
	/**
	 * @param loginId the loginId to set
	 */
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the sex
	 */
	public String getSex() {
		return sex;
	}
	/**
	 * @param sex the sex to set
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}
	/**
	 * @return the state
	 */
	public int getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(int state) {
		this.state = state;
	}
	
	
}
