package model;

import java.util.Date;
/**
 * 聊天记录每一行的类
 * 保存每一行的信息
 * @author Administrator
 *
 */
public class MessageRow {
	public static final int SENDER = 0;
	public static final int RECEIVER = 1;
	Date date;
	String message;
	int side;

	/**
	 * @param side
	 * @param date
	 * @param message
	 */
	public MessageRow(int side, Date date, String message) {
		super();
		this.side = side;
		this.date = date;
		this.message = message;
	}


	/**
	 * @return the side
	 */
	public int getSide() {
		return side;
	}
	
	
	public String stringify() {
		return side + "," + message;
	}


	/**
	 * @param side the side to set
	 */
	public void setSide(int side) {
		this.side = side;
	}


	/**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
}
