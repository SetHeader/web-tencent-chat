package model;

import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * 对已知用户的已知朋友的消息记录
 * 
 * @author Administrator
 *
 */
public class MessageRecord {
	int userId;	//用户序号
	int friendId;	//朋友序号
	List<MessageRow> messages;	//每行消息的列表
	
	public MessageRecord() {
		
	}

	public MessageRecord(int userId, int friendId) {
		this.userId = userId;
		this.friendId = friendId;
		messages = new LinkedList<>();
	}


	public void add(int side, Date date, String message) {
		MessageRow r = new MessageRow(side, date, message);
		messages.add(r);
	}
	
	public void add(int fromId, int toId, Date date, String message) {
		if (fromId == userId) 
		{
			add(MessageRow.SENDER, date, message);
		}
		else if (toId == userId)
		{
			add(MessageRow.RECEIVER, date, message);		
		}
	}

	/**
	 * @return the userId
	 */
	public int getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(int userId) {
		this.userId = userId;
	}

	/**
	 * @return the friendId
	 */
	public int getFriendId() {
		return friendId;
	}

	/**
	 * @param friendId the friendId to set
	 */
	public void setFriendId(int friendId) {
		this.friendId = friendId;
	}

	/**
	 * @return the messages
	 */
	public List<MessageRow> getMessages() {
		return messages;
	}

	/**
	 * @param messages the messages to set
	 */
	public void setMessages(List<MessageRow> messages) {
		this.messages = messages;
	}
	
	public String stringify() {
		String str = "";
		
		Iterator<MessageRow> it = messages.iterator();
		while (it.hasNext()) {
			str += it.next().stringify() + "&";
		}
		if (str.length() > 0)
		{
			str = str.substring(0, str.length()-1);
		}
//		System.out.println("stringify: " + str);
		return str;
	}
}