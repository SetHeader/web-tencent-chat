package jdbc;

import java.beans.Statement;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import model.MessageRecord;
import model.UserInf;

/**
 * 具体使用的与数据交互的类，继承DAO类
 * @author Administrator
 *
 */
public class UseDBProcedure extends DAO {
	/**
	 * 将用户登陆状态变为在线
	 * @param uid 用户id(不是注册id，是在数据库中保存的序号)
	 * @throws SQLException
	 */
	public void userLogin(int uid) throws SQLException {
		conn = OJDBC.getConn(name, pass);
		String sql = "begin\n user_login(?);\n end;";
		ps = conn.prepareStatement(sql);
		ps.setInt(1, uid);
		ps.execute();
		close();
	}
	/**
	 * 将用户登陆状态变为离线
	 * @param uid 用户id(不是注册id，是在数据库中保存的序号)
	 * @throws SQLException
	 */
	public void userOffline(int uid) throws SQLException {
		conn = OJDBC.getConn(name, pass);
		String sql = "begin\n user_offline(?);\n end;";
		ps = conn.prepareStatement(sql);
		ps.setInt(1, uid);
		ps.execute();
		close();
	}

	/**
	 * 用户注册
	 * @param loginId 注册账号
	 * @param password 注册密码
	 * @param nickname 昵称
	 * @param sex 性别
	 * @return 注册成功为真，失败为假
	 * @throws SQLException	
	 */
	public boolean userRegister(String loginId, String password, String nickname, String sex) throws SQLException {
		boolean flag = false;
		conn = OJDBC.getConn(name, pass);
		CallableStatement cs = conn.prepareCall("call user_register(?, ?, ?, ?, ?)");
		cs.setString(1, loginId);
		cs.setString(2, password);
		cs.setString(3, nickname);
		cs.setString(4, sex);
		cs.registerOutParameter(5, Types.INTEGER);
		cs.execute();
		int i = cs.getInt(5);
//		System.out.println("结果是" + i);
		if (i > 0) {
			flag = true;
		}

		close();
		return flag;
	}
	/**
	 * 让所有用户状态变为离线
	 * @throws Exception
	 */
	public void setAllOffline() throws Exception {
		String sql = "update user_inf set u_state = 1";
		conn = OJDBC.getConn(name, pass);
		ps = (PreparedStatement) conn.prepareStatement(sql);
		ps.execute();
		close();
	}
	/**
	 * 指定id的用户是否存在
	 * @param uid 用户id(不是注册id，是在数据库中保存的序号)
	 * @return 用户存在返回 true，不存在返回false
	 * @throws SQLException
	 */
	public boolean isExist(int uid) throws SQLException {
		boolean flag = false;
		conn = OJDBC.getConn(name, pass);
		String sql = "SELECT * FROM user_inf WHERE u_id = ?";
		ps = conn.prepareStatement(sql);
		ps.setInt(1, uid);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			flag = true;
		}
		close();
		return flag;
	}
	

	/**
	 * 指定账号是否存在
	 * @param loginId 用户账号
	 * @return 存在返回false， 不存在返回false
	 */
	@Override
	public boolean isExist(String loginId) throws SQLException {
		boolean flag = false;
		conn = OJDBC.getConn(name, pass);
		String sql = "SELECT * FROM user_inf WHERE u_loginid = ?";
		ps = conn.prepareStatement(sql);
		ps.setString(1, loginId);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			flag = true;
		}
		close();
		return flag;
	}
	/**
	 * 账号和密码是否正确
	 * @param loginId 用户账号
	 * @param password 用户密码
	 * @return 账号和密码存在且正确返回true，否则返回false
	 * @throws SQLException
	 */
	public boolean isExist(String loginId, String password) throws SQLException {
		boolean flag = false;
		conn = OJDBC.getConn(name, pass);
		String sql = "SELECT * FROM user_inf WHERE u_loginid = ? and u_password = ?";
		ps = conn.prepareStatement(sql);
		ps.setString(1, loginId);
		ps.setString(2, password);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			flag = true;
		}
		close();
		return flag;
	}

	/**
	 * 得到指定id用户的朋友列表 
	 * @param uid 用户id(不是注册id，是在数据库中保存的序号)
	 * @return 返回List<UserInf> 类型
	 * @throws SQLException
	 */
	public List getFriendList(int uid) throws SQLException {
		List<UserInf> list = new ArrayList<>();
		String sql = "SELECT U_ID, U_LOGINID, U_NICKNAME, U_SEX, U_STATE\n" + "  FROM user_inf\n"
				+ "  JOIN friends ON U_ID = F_FRIENDID\n" + "  WHERE F_USERID = ?";
		conn = OJDBC.getConn(name, pass);
		ps = conn.prepareStatement(sql);
		ps.setInt(1, uid);
		ResultSet rs = ps.executeQuery();
		UserInf u;
		int id;
		String loginId, pass, sex;
		int state;
		while (rs.next()) {
			id = rs.getInt(1);
			loginId = rs.getString(2);
			pass = rs.getString(3);
			sex = rs.getString(4);
			state = rs.getInt(5);
			u = new UserInf(id, loginId, pass, sex, state);
			list.add(u);
//			System.out.println(id + " : " + loginId + " : " + pass + " : " + 
//					sex + " : " + state);
		}
		close();
		return list;
	}
	/**
	 * 将消息加到数据库中
	 * @param message 消息内容
	 * @param fromId 从 fromId 发的
	 * @param toId 到 toId 去
	 * @throws SQLException
	 */
	public void addMessage(String message, int fromId, int toId) throws SQLException {
		conn = OJDBC.getConn(name, pass);
		CallableStatement cs = conn.prepareCall("call add_message(?, ?, ?)");
		cs.setString(1, message);
		cs.setInt(2, fromId);
		cs.setInt(3, toId);
		cs.execute();
		close();
	}
	/**
	 * 得到按时间升序的聊天记录
	 * @param userId 用户id（序号）
	 * @param friendId 朋友id（序号）
	 * @param topCount 取几条聊天记录
	 * @return 聊天记录类型
	 * @throws SQLException
	 */
	public MessageRecord getMessageASC(int userId, int friendId, int topCount) throws SQLException {
		MessageRecord mr = new MessageRecord(userId, friendId);
		String sql = "SELECT  M_message, m_time, m_fromuserid, m_touserid\n" + "  FROM messages_asc\n"
				+ "  WHERE ((m_fromuserid = ? AND m_touserid = ?) OR \n"
				+ "        (m_fromuserid = ? AND m_touserid = ?)) AND ROWNUM < ?";
		conn = OJDBC.getConn(name, pass);
		ps = conn.prepareStatement(sql);
		ps.setInt(1, userId);
		ps.setInt(2, friendId);
		ps.setInt(3, friendId);
		ps.setInt(4, userId);
		ps.setInt(5, topCount);
		ResultSet rs = ps.executeQuery();
		String message;
		int fromId, toId;
		Date date;

		DateFormat df = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
		while (rs.next()) {
			message = rs.getString(1);
			date = rs.getTimestamp(2);
			fromId = rs.getInt(3);
			toId = rs.getInt(4);
//			System.out.println("fromId " + fromId + " : toId " + toId + " : date " + df.format(date) + " : message " + message);
			mr.add(fromId, toId, date, message);
		}
		close();
		return mr;
	}
	/**
	 * 得到按时间 降序 的聊天记录
	 * @param userId 用户id（序号）
	 * @param friendId 朋友id（序号）
	 * @param topCount 取几条聊天记录
	 * @return 聊天记录类型
	 * @throws SQLException
	 */
	public MessageRecord getMessageDESC(int userId, int friendId, int topCount) throws SQLException {
		MessageRecord mr = new MessageRecord(userId, friendId);
		String sql = "SELECT  M_message, m_time, m_fromuserid, m_touserid\n" + "  FROM messages_desc\n"
				+ "  WHERE ((m_fromuserid = ? AND m_touserid = ?) OR \n"
				+ "        (m_fromuserid = ? AND m_touserid = ?)) AND ROWNUM < ?";
		conn = OJDBC.getConn(name, pass);
		ps = conn.prepareStatement(sql);
		ps.setInt(1, userId);
		ps.setInt(2, friendId);
		ps.setInt(3, friendId);
		ps.setInt(4, userId);
		ps.setInt(5, topCount);
		ResultSet rs = ps.executeQuery();
		String message;
		int fromId, toId;
		Date date;

		DateFormat df = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
		while (rs.next()) {
			message = rs.getString(1);
			date = rs.getTimestamp(2);
			fromId = rs.getInt(3);
			toId = rs.getInt(4);
//			System.out.println("fromId " + fromId + " : toId " + toId + " : date " + df.format(date) + " : message " + message);
			mr.add(fromId, toId, date, message);
		}
		close();
		return mr;
	}
	/**
	 * 得到按时间 降序 的聊天记录后再进行升序排列
	 * @param userId 用户id（序号）
	 * @param friendId 朋友id（序号）
	 * @param topCount 取几条聊天记录
	 * @return 聊天记录类型
	 * @throws SQLException
	 */
	public MessageRecord getMessageDESCOrderASC(int userId, int friendId, int topCount) throws SQLException {
		MessageRecord mr = new MessageRecord(userId, friendId);
		String sql = "SELECT  M_message, m_time, m_fromuserid, m_touserid\n" + "  FROM messages_desc\n"
				+ "  WHERE ((m_fromuserid = ? AND m_touserid = ?) OR \n"
				+ "        (m_fromuserid = ? AND m_touserid = ?)) AND ROWNUM < ?\n" + "ORDER BY M_TIME ASC";
		conn = OJDBC.getConn(name, pass);
		ps = conn.prepareStatement(sql);
		ps.setInt(1, userId);
		ps.setInt(2, friendId);
		ps.setInt(3, friendId);
		ps.setInt(4, userId);
		ps.setInt(5, topCount);
		ResultSet rs = ps.executeQuery();
		String message;
		int fromId, toId;
		Date date;

		DateFormat df = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
		while (rs.next()) {
			message = rs.getString(1);
			date = rs.getTimestamp(2);
			fromId = rs.getInt(3);
			toId = rs.getInt(4);
//			System.out.println("fromId " + fromId + " : toId " + toId + " : date " + df.format(date) + " : message " + message);
			mr.add(fromId, toId, date, message);
		}
		close();
		return mr;
	}
	/**
	 * 增加朋友
	 * @param uId 用户序号
	 * @param friendId 朋友序号
	 * @throws SQLException
	 */
	public void addFriend(int uId, int friendId) throws SQLException {
		String sql = "call add_friend(?, ?)";
		conn = OJDBC.getConn(name, pass);
		CallableStatement cs = conn.prepareCall(sql);
		cs.setInt(1, uId);
		cs.setInt(2, friendId);
		cs.execute();
		close();
	}
	/**
	 * 得到用户信息
	 * @param loginId 账号
	 * @param password 密码
	 * @return
	 * @throws SQLException
	 */
	public UserInf getUserInf(String loginId, String password) throws SQLException {
		UserInf u = null;
		int id;
		String sql = "select U_ID, U_NICKNAME, U_SEX from user_inf where u_loginid = ? and u_password = ?";
		conn = OJDBC.getConn(name, pass);
		ps = conn.prepareStatement(sql);
		ps.setString(1, loginId);
		ps.setString(2, password);
		ResultSet rs = ps.executeQuery();

		if (rs.next()) {
			u = new UserInf(rs.getInt(1), loginId, rs.getString(2), rs.getString(3));
		}

		close();
		return u;
	}
	/**
	 * 得到用户信息
	 * @param loginId 账号
	 * @return 返回用户信息
	 */
	public UserInf getUserInf(String loginId) throws SQLException {
		UserInf u = null;
		int id;
		String sql = "select U_ID, U_NICKNAME, U_SEX from user_inf where u_loginid = ?";
		conn = OJDBC.getConn(name, pass);
		ps = conn.prepareStatement(sql);
		ps.setString(1, loginId);
		ResultSet rs = ps.executeQuery();

		if (rs.next()) {
			u = new UserInf(rs.getInt(1), loginId, rs.getString(2), rs.getString(3));
		}

		close();
		return u;
	}

	/**
	 * 得到所有用户信息列表
	 * @return 返回类型List<UserInf>
	 * @throws SQLException
	 */
	public List getUserList() throws SQLException {
		List<UserInf> list = new ArrayList<>();
		String sql = "SELECT U_ID, U_LOGINID, U_NICKNAME, U_SEX, U_STATE\n" + "  FROM user_inf\n";
		conn = OJDBC.getConn(name, pass);
		ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		UserInf u;
		int id;
		String loginId, pass, sex;
		int state;
		while (rs.next()) {
			id = rs.getInt(1);
			loginId = rs.getString(2);
			pass = rs.getString(3);
			sex = rs.getString(4);
			state = rs.getInt(5);
			u = new UserInf(id, loginId, pass, sex, state);
			list.add(u);
//			System.out.println(id + " : " + loginId + " : " + pass + " : " + 
//					sex + " : " + state);
		}
		close();
		return list;
	}
}
