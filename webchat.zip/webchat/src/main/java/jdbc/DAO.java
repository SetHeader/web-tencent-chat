package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * 基础DAO类，提数据库连接时的账号和密码
 * @author Administrator
 *
 */
public class DAO {
	final String name = "super_user";
	final String pass = "superuser";
	Connection conn;
	Statement st;
	PreparedStatement ps;

	public ResultSet query(String sql) throws SQLException {
		conn = OJDBC.getConn(name, pass);
		st = conn.createStatement();

		ResultSet rs = st.executeQuery(sql);

		close();
		return rs;
	}

	public void add(String sql) {

	}

	public void delete(String sql) {

	}

	public void update(String sql) {

	}

	public boolean isExist(String sql) throws SQLException {
		boolean flag = false;

		conn = OJDBC.getConn(name, pass);
		try {
			st = conn.createStatement();
			if (st.executeUpdate(sql) > 0) {
				flag = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return flag;
	}

	/**
	 * 关闭全部连接
	 */
	public void close() {
		try {
			if (st != null) {
				st.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			if (ps != null) {
				ps.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
