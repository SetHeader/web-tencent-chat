package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jdbc.UseDBProcedure;
import model.UserInf;

public class OfflineServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) {
		req.getSession().setMaxInactiveInterval(10);
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res);
	}
}
