package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jdbc.UseDBProcedure;
import model.User;
import model.UserInf;
/**
 * 登陆界面的登陆处理servlet
 * @author Administrator
 *
 */
public class LoginServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) {
		String loginId, password;
		loginId = req.getParameter("id");
		password = req.getParameter("password");

		UseDBProcedure pro = new UseDBProcedure();
		UserInf u = null;
		try {
			u = pro.getUserInf(loginId, password);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		if (u != null)
		{			
			HttpSession session = req.getSession();
			session.setAttribute("userInf", u);
			try {
				req.getRequestDispatcher("welcome").forward(req, res);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(u.getName() + ": 登陆成功");
			try {
				pro.userLogin(u.getId());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			try {
				res.sendRedirect("login.html");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("账号或密码错误");
		}
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res);
	}
}
