package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jdbc.UseDBProcedure;
import model.User;
import model.UserInf;

public class AddMessageServlet extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) {
		
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("user");
		UserInf friend = (UserInf) session.getAttribute("friend");
		String message = req.getParameter("message");
		
		System.out.println("收到信息 :" + message);
		
		UseDBProcedure pro = new UseDBProcedure();
		try {
			pro.addMessage(message, user.getUserInf().getId(), friend.getId());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			res.getWriter().write("yes");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res);
	}
}