package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jdbc.UseDBProcedure;
/**
 * 注册用户servlet
 * @author Administrator
 *
 */
public class RegisterServlet extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) {
		HttpSession session = req.getSession();
		String loginId = req.getParameter("loginId");
		String password = req.getParameter("password");
		String name = req.getParameter("name");
		String sex = req.getParameter("sex");
		UseDBProcedure pro = new UseDBProcedure();
		
		System.out.println(req.getQueryString());
		System.out.println(loginId + ":" + password + ":" + name + ":" + sex);
		
		res.setContentType("text/html; charset=UTF-8");
		res.setCharacterEncoding("UTF-8");
		
		try {
			boolean isOk = pro.userRegister(loginId, password, name, sex);
			if (isOk)
			{
				res.getWriter().write("注册成功");
			}
			else
			{
				res.getWriter().write("注册成失败");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			try {
				res.getWriter().write("注册成失败");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res);
	}
}