package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jdbc.UseDBProcedure;
import model.MessageRecord;
import model.User;
import model.UserInf;

public class GetMessageServlet extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) {
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("user");
		UserInf friend = (UserInf) session.getAttribute("friend");
		String message = req.getParameter("message");
		UseDBProcedure pro = new UseDBProcedure();
		
		try {
			res.setCharacterEncoding("UTF-8");
			res.setContentType("text/html; charset=UTF-8"); 
			MessageRecord mr = pro.getMessageDESC(user.getUserInf().getId(), friend.getId(), 10);
			res.getWriter().write(mr.stringify());
		} catch (SQLException | IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res);
	}
}