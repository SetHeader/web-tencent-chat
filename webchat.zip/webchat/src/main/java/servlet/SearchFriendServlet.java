package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jdbc.UseDBProcedure;
import model.User;
import model.UserInf;
/**
 * 添加好友界面的那个查找朋友按钮，点击后的处理servlet
 * 朋友存在则显示那个朋友
 * 朋友不存在，显示所有用户
 * @author Administrator
 *
 */
public class SearchFriendServlet extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) {
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("user");
		String friendLoginId = req.getParameter("loginId");
		UseDBProcedure pro = new UseDBProcedure();
		UserInf friend = null;
		try {
			friend = pro.getUserInf(friendLoginId);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		if (friend == null)
		{
			try {
				List<UserInf> userInfList = pro.getUserList();
				session.setAttribute("userInfList", userInfList);
				req.getRequestDispatcher("add.jsp").forward(req, res);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			List<UserInf> userInfList = new ArrayList<>();
			try {
				userInfList.add(friend);
				session.setAttribute("userInfList", userInfList);
				req.getRequestDispatcher("add.jsp").forward(req, res);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res);
	}
}