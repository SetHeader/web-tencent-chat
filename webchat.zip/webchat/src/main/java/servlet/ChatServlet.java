package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jdbc.UseDBProcedure;
import model.MessageRecord;
import model.User;
import model.UserInf;
/**
 * 进入聊天界面前的处理servlet
 * @author Administrator
 *
 */
public class ChatServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) {
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("user");
		UserInf friendInf = null;
		try {
			friendInf = user.getFriendByIndex(Integer.parseInt(req.getParameter("num")));
		} catch (NullPointerException e) {
//			System.out.println("当前无用户");
			try {
				res.sendRedirect("login.html");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} finally {
				return ;
			}
		}
		session.setAttribute("friend", friendInf);
		UseDBProcedure pro = new UseDBProcedure();
		try {
			MessageRecord mr = pro.getMessageDESCOrderASC(user.getUserInf().getId(), friendInf.getId(), 100);
			session.setAttribute("messages", mr.getMessages());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			req.getRequestDispatcher("chat.jsp").forward(req, res);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res);
	}
}
