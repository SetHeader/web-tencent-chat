package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jdbc.UseDBProcedure;
import model.MessageRecord;
import model.User;
import model.UserInf;
/**
 * 登陆成功后的处理
 * @author Administrator
 *
 */
public class WelcomeServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) {
		HttpSession session = req.getSession();
		UseDBProcedure pro = new UseDBProcedure();
		UserInf u = (UserInf) session.getAttribute("userInf");

		if (u == null) {
			res.setContentType("text/html; charset=UTF-8");
			res.setCharacterEncoding("UTF-8");
			try {
				res.getWriter().write("出错了");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return ;
		}

		List<UserInf> friends = null;
		try {
			friends = pro.getFriendList(u.getId());
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		session.setAttribute("user", new User(u, friends));
		try {
			req.getRequestDispatcher("welcome.jsp").forward(req, res);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res);
	}
}
