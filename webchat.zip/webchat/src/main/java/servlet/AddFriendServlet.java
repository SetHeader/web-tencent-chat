package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jdbc.UseDBProcedure;
import model.MessageRecord;
import model.User;
import model.UserInf;
/**
 * 添加好友时使用的servet
 * @author Administrator
 *
 */
public class AddFriendServlet extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) {
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("user");
		List<UserInf> userInfList = (List<UserInf>) session.getAttribute("userInfList");
		int num = Integer.parseInt(req.getParameter("num"));
		System.out.println("第" + num + "个");
		UseDBProcedure pro = new UseDBProcedure();
		
		try {
			System.out.println(user.getUserInf().getName() + " 添加好友 " + userInfList.get(num).getName());
			pro.addFriend(user.getUserInf().getId(), userInfList.get(num).getId());
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
//			System.out.println("好友已存在");
		} catch (NullPointerException e) {
//			System.out.println("不能添加已存在好友");
		} finally {
			try {
				req.getRequestDispatcher("welcome").forward(req, res);
			} catch (ServletException | IOException e) {
				// TODO Auto-generated catch block
				
			}
		}
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res);
	}
}